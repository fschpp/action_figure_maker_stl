# Catálogo «proceres-127»

_Generado por afm 0.2.1. No editar a mano: `afm catalogo listar`._

- Altura de la línea: **127 mm** · boquilla **0.4 mm** · holgura **0.5 mm**

| Pieza | Nombre | Tipo | Estado | Etiquetas | Puertos | Origen | Volumen (mm³) |
|---|---|---|---|---|---|---|---|
| `brazo-belgrano-lq-rsized-fixed-ok-01@4` | belgrano-brazo | brazo | borrador | — | hombro, muneca | belgrano_lq_rsized_fixed_ok.stl | 3185 |
| `brazo-belgrano-lq-rsized-fixed-ok-01@5` | belgrano-brazo | brazo | borrador | — | hombro, muneca | belgrano_lq_rsized_fixed_ok.stl | 3185 |
| `brazo-guemes-segmentado-lq-fixed-resized-01@2` | guemes-brazo | brazo | borrador | — | hombro, muneca | guemes_segmentado_lq_fixed_resized.stl | 2964 |
| `brazo-guemes-segmentado-lq-fixed-resized-01@3` | guemes-brazo | brazo | borrador | — | hombro, muneca | guemes_segmentado_lq_fixed_resized.stl | 2964 |
| `brazo-sanmartin-01@2` | sanmartin-brazo | brazo | borrador | — | hombro, muneca | sanmartin.stl | 3389 |
| `brazo-sanmartin-01@3` | sanmartin-brazo | brazo | borrador | — | hombro, muneca | sanmartin.stl | 3389 |
| `brazo-simon-bolivar-cuerpo-fixed-01@2` | bolivar-brazo | brazo | borrador | — | hombro, muneca | simon_bolivar_cuerpo_fixed.stl | 2994 |
| `brazo-simon-bolivar-cuerpo-fixed-01@3` | bolivar-brazo | brazo | borrador | — | hombro, muneca | simon_bolivar_cuerpo_fixed.stl | 2994 |
| `brazo-sucre-cuerpo-01@2` | sucre-brazo | brazo | borrador | — | hombro, muneca | sucre_cuerpo.stl | 3014 |
| `brazo-sucre-cuerpo-01@3` | sucre-brazo | brazo | borrador | — | hombro, muneca | sucre_cuerpo.stl | 3014 |
| `cabeza-belgrano-lq-rsized-fixed-ok-01@5` | belgrano-cabeza | cabeza | borrador | — | cuello | belgrano_lq_rsized_fixed_ok.stl | 2583 |
| `cabeza-belgrano-lq-rsized-fixed-ok-01@6` | belgrano-cabeza | cabeza | borrador | — | cuello | belgrano_lq_rsized_fixed_ok.stl | 2583 |
| `cabeza-guemes-segmentado-lq-fixed-resized-01@2` | guemes-cabeza | cabeza | borrador | — | cuello | guemes_segmentado_lq_fixed_resized.stl | 2719 |
| `cabeza-guemes-segmentado-lq-fixed-resized-01@3` | guemes-cabeza | cabeza | borrador | — | cuello | guemes_segmentado_lq_fixed_resized.stl | 2719 |
| `cabeza-guemes-segmentado-lq-fixed-resized-01@4` | guemes-cabeza | cabeza | borrador | — | cuello | guemes_segmentado_lq_fixed_resized.stl | 2719 |
| `cabeza-sanmartin-01@1` | sanmartin-cabeza | cabeza | borrador | — | cuello | sanmartin.stl | 184 |
| `cabeza-sanmartin-01@2` | sanmartin-cabeza | cabeza | borrador | — | cuello | sanmartin.stl | 184 |
| `cabeza-sanmartin-01@3` | sanmartin-cabeza | cabeza | borrador | — | cuello | sanmartin.stl | 184 |
| `cabeza-simon-bolivar-cuerpo-fixed-01@1` | bolivar-cabeza | cabeza | borrador | — | cuello | simon_bolivar_cuerpo_fixed.stl | 3007 |
| `cabeza-simon-bolivar-cuerpo-fixed-01@2` | bolivar-cabeza | cabeza | borrador | — | cuello | simon_bolivar_cuerpo_fixed.stl | 3007 |
| `cabeza-sucre-cuerpo-01@1` | sucre-cabeza | cabeza | borrador | — | cuello | sucre_cuerpo.stl | 2770 |
| `mano-guemes-segmentado-lq-fixed-resized-01@1` | guemes-mano | mano | borrador | — | muneca | guemes_segmentado_lq_fixed_resized.stl | 319 |
| `mano-guemes-segmentado-lq-fixed-resized-01@2` | guemes-mano | mano | borrador | — | muneca | guemes_segmentado_lq_fixed_resized.stl | 319 |
| `mano-guemes-segmentado-lq-fixed-resized-01@3` | guemes-mano | mano | borrador | — | muneca, agarre Ø2.4 | guemes_segmentado_lq_fixed_resized.stl | 313 |
| `pelvis-guemes-segmentado-lq-fixed-resized-01@1` | guemes.pelvis | pelvis | borrador | — | cintura, cadera_izq, cadera_der | guemes_segmentado_lq_fixed_resized.stl | 7775 |
| `pelvis-guemes-segmentado-lq-fixed-resized-01@2` | guemes.pelvis | pelvis | borrador | — | cintura, cadera_izq, cadera_der | guemes_segmentado_lq_fixed_resized.stl | 7775 |
| `pierna-guemes-segmentado-lq-fixed-resized-01@1` | guemes-pierna | pierna | borrador | — | cadera | guemes_segmentado_lq_fixed_resized.stl | 5709 |
| `pierna-guemes-segmentado-lq-fixed-resized-01@2` | guemes-pierna | pierna | borrador | — | cadera | guemes_segmentado_lq_fixed_resized.stl | 5709 |
| `torso-sup-belgrano-lq-rsized-fixed-ok-01@3` | belgrano-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | belgrano_lq_rsized_fixed_ok.stl | 11930 |
| `torso-sup-belgrano-lq-rsized-fixed-ok-01@4` | belgrano-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | belgrano_lq_rsized_fixed_ok.stl | 11930 |
| `torso-sup-guemes-segmentado-lq-fixed-resized-01@1` | guemes-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | guemes_segmentado_lq_fixed_resized.stl | 11504 |
| `torso-sup-guemes-segmentado-lq-fixed-resized-01@2` | guemes-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | guemes_segmentado_lq_fixed_resized.stl | 11504 |
| `torso-sup-sanmartin-01@1` | sanmartin-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | sanmartin.stl | 11504 |
| `torso-sup-sanmartin-01@2` | sanmartin-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | sanmartin.stl | 11504 |
| `torso-sup-simon-bolivar-cuerpo-fixed-01@5` | bolivar-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | simon_bolivar_cuerpo_fixed.stl | 10363 |
| `torso-sup-simon-bolivar-cuerpo-fixed-01@6` | bolivar-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | simon_bolivar_cuerpo_fixed.stl | 10363 |
| `torso-sup-sucre-cuerpo-01@1` | sucre-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | sucre_cuerpo.stl | 9450 |
| `torso-sup-sucre-cuerpo-01@2` | sucre-torso | torso_sup | borrador | — | cuello, hombro_izq, hombro_der, cintura | sucre_cuerpo.stl | 9450 |
